package com.modid;

/** FreeLook durumu: aktifken kamera açısı (yaw/pitch) oyuncunun gerçek bakışından bağımsızdır. */
public final class FreeLook {
    private FreeLook() {}

    public static boolean active;
    public static float yaw, pitch;
}
