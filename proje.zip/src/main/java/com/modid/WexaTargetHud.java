package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Nursultan tarzı Target HUD. Sohbet açıkken sürüklenir. ESP: esp1..esp5 (beyaz, hedefin etrafında döner). */
public class WexaTargetHud extends Module {
    public final Setting.Bool esp = add(new Setting.Bool("ESP", true));
    public final Setting.Mode espStyle = add(new Setting.Mode("ESP Style", new String[]{"esp1", "esp2", "esp3", "esp4", "esp5"}));
    public final Setting.Bool items = add(new Setting.Bool("Items", true));

    private float shownHp = -1f;
    private LivingEntity last;

    public WexaTargetHud() {
        super("Target HUD", "Render");
    }

    private LivingEntity pick(MinecraftClient mc) {
        Aura a = Modules.AURA;
        if (a != null && a.isEnabled() && a.current != null && a.current.isAlive()) return a.current;
        ElytraTarget et = ElytraTarget.I;
        if (et.isEnabled() && et.target != null && et.target.isAlive()) return et.target;
        if (mc.currentScreen instanceof ChatScreen) return mc.player;
        return null;
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        LivingEntity t = pick(mc);
        if (t == null) {
            last = null;
            return;
        }
        if (t != last) {
            last = t;
            shownHp = t.getHealth();
        }
        float hp = t.getHealth() + t.getAbsorptionAmount();
        float max = Math.max(1f, t.getMaxHealth());
        shownHp += (hp - shownHp) * 0.15f;

        var tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int w = 150, h = 44;
        int[] pos = HudPos.pos("targethud", sw / 2 + 40, sh / 2 + 40);
        HudPos.drag(mc, "targethud", pos, w, h);
        int x = pos[0], y = pos[1];

        Ui.rrect(ctx, x, y, w, h, 6, Ui.BG);

        Ui.rrect(ctx, x + 5, y + 5, 34, 34, 5, 0xFF1D2127);
        Identifier skin = null;
        if (t instanceof AbstractClientPlayerEntity ap) skin = ap.getSkinTextures().texture();
        if (skin != null) {
            ctx.drawTexture(skin, x + 7, y + 7, 30, 30, 8f, 8f, 8, 8, 64, 64);
            ctx.drawTexture(skin, x + 7, y + 7, 30, 30, 40f, 8f, 8, 8, 64, 64);
        } else {
            String ch = t.getName().getString().isEmpty() ? "?" : t.getName().getString().substring(0, 1).toUpperCase();
            ctx.drawText(tr, ch, x + 5 + (34 - tr.getWidth(ch)) / 2, y + 18, Ui.TEXT, false);
        }

        String name = t.getName().getString();
        while (tr.getWidth(name) > w - 52 && name.length() > 3) name = name.substring(0, name.length() - 1);
        ctx.drawText(tr, name, x + 45, y + 6, Ui.TEXT, true);

        float ratio = MathHelper.clamp(shownHp / max, 0f, 1f);
        int bx = x + 45, by = y + 19, bw = w - 52, bh = 6;
        Ui.rrect(ctx, bx, by, bw, bh, 3, Ui.TRACK);
        int col = ratio > 0.5f ? Ui.mix(0xFFE5C14A, Ui.ACCENT, (ratio - 0.5f) * 2f) : Ui.mix(0xFFE5483A, 0xFFE5C14A, ratio * 2f);
        Ui.rrect(ctx, bx, by, Math.max(4, (int) (bw * ratio)), bh, 3, col);
        ctx.drawText(tr, String.format("%.1f HP", hp), x + 45, y + 29, Ui.DIM, false);

        if (items.get()) {
            ItemStack[] st = {
                    t.getEquippedStack(EquipmentSlot.HEAD), t.getEquippedStack(EquipmentSlot.CHEST),
                    t.getEquippedStack(EquipmentSlot.LEGS), t.getEquippedStack(EquipmentSlot.FEET),
                    t.getMainHandStack()};
            int ix = x + 45 + 48;
            for (ItemStack s : st) {
                if (!s.isEmpty()) {
                    MatrixStack m = ctx.getMatrices();
                    m.push();
                    m.translate(ix, y + 27, 0);
                    m.scale(0.6f, 0.6f, 1f);
                    ctx.drawItem(s, 0, 0);
                    m.pop();
                }
                ix += 10;
            }
        }

        HudPos.outline(ctx, mc, x, y, w, h);
        if (esp.get() && t != mc.player) Esp.draw(ctx, mc, t, espStyle.get());
    }
}
