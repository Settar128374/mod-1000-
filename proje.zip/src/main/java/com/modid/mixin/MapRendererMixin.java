package com.modid.mixin;

import com.modid.NoRender;
import net.minecraft.client.render.MapRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MapRenderer.class)
public abstract class MapRendererMixin {
    @Inject(method = "draw", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$map(CallbackInfo ci) {
        if (NoRender.on(NoRender.I.maps)) ci.cancel();
    }
}
