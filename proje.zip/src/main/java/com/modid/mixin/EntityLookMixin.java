package com.modid.mixin;

import com.modid.FreeLook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityLookMixin {
    /** FreeLook açıkken fare hareketi oyuncuyu değil kamerayı döndürür. */
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void modid$look(double dx, double dy, CallbackInfo ci) {
        if (!FreeLook.active) return;
        if ((Object) this != MinecraftClient.getInstance().player) return;
        FreeLook.yaw += (float) dx * 0.15f;
        FreeLook.pitch = MathHelper.clamp(FreeLook.pitch + (float) dy * 0.15f, -90f, 90f);
        ci.cancel();
    }
}
