package com.modid;

/** Tek giriş noktası: ModIDClient'te CombatExtras ve NoRender'dan SONRA Wexa.register() çağır. */
public final class Wexa {
    private Wexa() {}

    public static void register() {
        Modules.ALL.removeIf(m -> m instanceof Modules.TargetHud);

        Modules.ALL.add(ElytraTarget.I);
        Modules.ALL.add(new ElytraMotion());
        Modules.ALL.add(new ElytraBooster());
        Modules.ALL.add(new KeyBinds());
        Modules.ALL.add(new WaterMark());
        Modules.ALL.add(new WexaTargetHud());

        Config.load(); // kayıtlı ayarları geri yükle (en sonda)
    }
}
