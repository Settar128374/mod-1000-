package com.modid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Açık modüllerin listesi (Nursultan "Keybinds" paneli gibi). Aura açılınca "Aura" yazar. */
public class KeyBinds extends Module {
    private static final Set<String> HIDE = Set.of("Key Binds", "Water Mark", "Target HUD");

    public KeyBinds() {
        super("Key Binds", "Combat");
    }

    @Override
    public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        var tr = mc.textRenderer;
        boolean chat = mc.currentScreen instanceof ChatScreen;

        List<String> rows = new ArrayList<>();
        for (Module m : Modules.ALL) if (m.isEnabled() && !HIDE.contains(m.name)) rows.add(m.name);
        if (rows.isEmpty() && !chat) return;

        String right = "Toggle";
        int rw = tr.getWidth(right);
        int w = tr.getWidth("Keybinds") + 24;
        for (String r : rows) w = Math.max(w, tr.getWidth(r) + rw + 26);
        w = Math.max(w, 100);
        int rowH = 12, h = 22 + rows.size() * rowH + 3;

        int[] pos = HudPos.pos("keybinds", 6, 34);
        HudPos.drag(mc, "keybinds", pos, w, h);
        int x = pos[0], y = pos[1];

        Ui.rrect(ctx, x, y, w, h, 5, Ui.BG);
        ctx.drawText(tr, "Keybinds", x + 8, y + 7, Ui.ACCENT, true);
        ctx.fill(x + 8, y + 18, x + w - 8, y + 19, 0x22FFFFFF);
        int ry = y + 22;
        for (String r : rows) {
            ctx.drawText(tr, r, x + 8, ry, Ui.TEXT, false);
            ctx.drawText(tr, right, x + w - 8 - rw, ry, Ui.DIM, false);
            ry += rowH;
        }
        HudPos.outline(ctx, mc, x, y, w, h);
    }
}
